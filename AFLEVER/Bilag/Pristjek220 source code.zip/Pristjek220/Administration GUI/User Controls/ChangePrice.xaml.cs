﻿using System.Windows.Controls;

namespace Administration_GUI.User_Controls
{
    /// <summary>
    /// Interaction logic for ChangePrice.xaml
    /// </summary>
    public partial class ChangePrice
    {
        /// <summary>
        /// 
        /// </summary>
        public ChangePrice()
        {
            InitializeComponent();
        }
    }
}
