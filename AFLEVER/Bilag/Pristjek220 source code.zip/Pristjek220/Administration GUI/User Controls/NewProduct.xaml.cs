﻿using System.Windows.Controls;

namespace Administration_GUI.User_Controls
{
    /// <summary>
    /// Interaction logic for NewProduct.xaml
    /// </summary>
    public partial class NewProduct
    {
        /// <summary>
        /// 
        /// </summary>
        public NewProduct()
        {
            InitializeComponent();
        }
    }
}