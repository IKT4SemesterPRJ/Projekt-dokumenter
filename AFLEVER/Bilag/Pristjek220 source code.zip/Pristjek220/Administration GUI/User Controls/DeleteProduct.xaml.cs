﻿using System.Windows.Controls;

namespace Administration_GUI.User_Controls
{
    /// <summary>
    /// Interaction logic for DeleteProduct.xaml
    /// </summary>
    public partial class DeleteProduct
    {
        /// <summary>
        /// 
        /// </summary>
        public DeleteProduct()
        {
            InitializeComponent();
        }
    }
}
