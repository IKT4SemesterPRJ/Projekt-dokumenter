﻿using System.Windows.Controls;

namespace Administration_GUI.User_Controls_Admin
{
    /// <summary>
    /// Interaction logic for AdminDeleteProduct.xaml
    /// </summary>
    public partial class AdminDeleteProduct
    {
        /// <summary>
        ///     
        /// </summary>
        public AdminDeleteProduct()
        {
            InitializeComponent();
        }
    }
}
