﻿using System.Runtime.CompilerServices;
using Administration_GUI;
using Pristjek220Data;
using SharedFunctionalities;

[assembly: InternalsVisibleTo("Pristjek220.Unit.Test")]

namespace Administration_GUI.User_Controls_Admin
{
    /// <summary>
    ///     Not implemented
    /// </summary>
    class AdminDeleteProductModel : ObservableObject, IPageViewModel
    {
        /// <summary>
        ///     Not implemented
        /// </summary>
        public AdminDeleteProductModel()
        {
            
        }
    }
}
