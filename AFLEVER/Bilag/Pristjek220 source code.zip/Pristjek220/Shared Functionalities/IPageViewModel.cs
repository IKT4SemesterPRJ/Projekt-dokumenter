﻿namespace SharedFunctionalities
{
    /// <summary>
    ///     Interface that all the User Controlls are inheriting from, so they can all be in the same list.
    /// </summary>
    public interface IPageViewModel
    {
    }
}