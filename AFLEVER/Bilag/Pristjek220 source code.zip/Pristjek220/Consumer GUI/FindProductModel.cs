﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consumer_GUI.User_Controls
{
    class FindProductModel : ObservableObject, IPageViewModel
    {
        public string Name
        {
            get
            {
                return "Find Page";
            }
        }
    }
}
