﻿using System.Windows.Controls;

namespace Consumer_GUI.User_Controls
{
    /// <summary>
    /// Interaction logic for FindProduct.xaml
    /// </summary>
    public partial class FindProduct
    {
        /// <summary>
        /// 
        /// </summary>
        public FindProduct()
        {
            InitializeComponent();
        }
    }
}
