﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharedFunctionalities;

namespace Consumer_GUI.User_Controls
{
    /// <summary>
    ///     Not implemented
    /// </summary>
    public class HomeModel : ObservableObject, IPageViewModel
    {}
}
