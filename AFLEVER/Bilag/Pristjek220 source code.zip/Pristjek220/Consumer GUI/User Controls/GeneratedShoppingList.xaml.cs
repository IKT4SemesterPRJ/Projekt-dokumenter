﻿using System.Windows.Controls;

namespace Consumer_GUI.User_Controls
{
    /// <summary>
    /// Interaction logic for GeneratedShoppingList.xaml
    /// </summary>
    public partial class GeneratedShoppingList
    {
        
        /// <summary>
        /// 
        /// </summary>
        public GeneratedShoppingList()
        {
            InitializeComponent();
        }
    }
}
