﻿using System.Windows.Controls;

namespace Consumer_GUI.User_Controls
{
    /// <summary>
    /// Interaction logic for ShoppingList.xaml
    /// </summary>
    public partial class ShoppingList
    {
        /// <summary>
        /// 
        /// </summary>
        public ShoppingList()
        {
            InitializeComponent();
        }
    }
}
