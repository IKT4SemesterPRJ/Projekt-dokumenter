﻿using System.Windows.Controls;

namespace Consumer_GUI.User_Controls
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home
    {
        /// <summary>
        /// 
        /// </summary>
        public Home()
        {
            InitializeComponent();
        }
    }
}
